_base_ = './2dsn.py'
model = dict(
    type='AutoAssign',
    pretrained='/home/airstudio/pretrained model/RegNetX-3.2GF.pth',
    backbone=dict(
        type='RegNet',
        arch='regnetx_3.2gf',
        frozen_stages=1,
        norm_cfg=dict(type='BN', requires_grad=True),
        norm_eval=True,
        style='pytorch'),
    neck=dict(
        type='FPN',
        in_channels=[96, 192, 432, 1008],
        out_channels=128,
        start_level=1,
        add_extra_convs=True,
        extra_convs_on_inputs=True,
        num_outs=5,
        relu_before_extra_convs=True,
        init_cfg=dict(type='Caffe2Xavier', layer='Conv2d')),
    bbox_head=dict(
        type='AutoAssignHead',
        num_classes=15,
        in_channels=128,
        stacked_convs=4,
        feat_channels=128,
        strides=[8, 16, 32, 64, 128],
        loss_bbox=dict(type='GIoULoss', loss_weight=5.0)),
    train_cfg=None,
    test_cfg=dict(
        nms_pre=2000,
        min_bbox_size=0,
        score_thr=0.05,
        nms=dict(type='nms', iou_threshold=0.4),
        max_per_img=1000))

optimizer = dict(lr=0.005, paramwise_cfg=dict(norm_decay_mult=0.))
